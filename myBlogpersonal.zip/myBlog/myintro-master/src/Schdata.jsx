const Schdata = [
    {
        title: "Undergraduate  ",
        textdata : "Gautam Buddha University, Greater Noida (7.7 CGPA) "
    },
    {
        title: "Intermediate",
        textdata : "Private candidate CBSE Board (2017)"
    },
    {
        title: "High School",
        textdata : "Nav Jeevan Mission School, Kasia (9.4 CGPA)"
    }
]

export default Schdata;