import React  from 'react'

const Footer =()=>{
    return (
        <>
        <div className="container-fluid ">
            <div className="row">
                <div className="col-10 mx-auto">

                <footer className="bg-light mt-3 text-center mb-0">
                <p> &#169;  Akash.&nbsp;&nbsp;    Built with  &#x1F496; by Akash Patel </p>
                </footer>

            </div> 
            </div> 
            </div>
        
        </>
    )
}

export default Footer;