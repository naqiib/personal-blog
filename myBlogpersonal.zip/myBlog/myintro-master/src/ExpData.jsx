const ExpData = [
    {
        title: "More, Coming Soon ... ",
        textdata : "Stay Updated ",
        mylink : ''
    },
    {
        title: "My Portfolio website",
        textdata : "MyIntro ",
        mylink : 'https://github.com/imakash3011/myintro'
    },
    {
        title: "Content Writing Intern ",
        textdata : "Internship at EduTekzila (2 months)",
        mylink : 'https://www.linkedin.com/posts/imakash3011_internship-edutekzila-python-activity-6737423929062830081-dHI1'
    },
    {
        title: "Data Science and Business Analytics Intern",
        textdata : "Intern at The Sparks Foundation",
        mylink : 'https://www.linkedin.com/posts/imakash3011_internship2020-datascientist-gripnov20-activity-6739549942085431296-aXwU'
    },
    {
        title: "Cloth-Detector ",
        textdata : "Machine learning project (with my team)",
        mylink : 'https://github.com/imakash3011/ClothDetector'
    }
]

export default ExpData;